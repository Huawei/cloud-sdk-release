ServiceFilter
==============
.. automodule:: openstack.service_filter


ServiceFilter object
--------------------

.. autoclass:: openstack.service_filter.ServiceFilter
   :members:

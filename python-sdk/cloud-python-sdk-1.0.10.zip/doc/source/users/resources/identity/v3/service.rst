openstack.identity.v3.service
=============================

.. automodule:: openstack.identity.v3.service

The Service Class
-----------------

The ``Service`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.identity.v3.service.Service
   :members:

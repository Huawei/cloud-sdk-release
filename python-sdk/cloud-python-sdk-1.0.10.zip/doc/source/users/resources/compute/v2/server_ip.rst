openstack.compute.v2.server_ip
==============================

.. automodule:: openstack.compute.v2.server_ip

The ServerIP Class
------------------

The ``ServerIP`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.compute.v2.server_ip.ServerIP
   :members:

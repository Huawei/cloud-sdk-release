openstack.rds.v1.datastore
==========================

.. automodule:: openstack.rds.v1.datastore

The Version Class
-----------------

The ``Version`` class inherits from
    :class:`~openstack.rds.v1.rdsresource.Resource`.

.. autoclass:: openstack.rds.v1.datastore.Version
   :members:

The Parameter Class
-------------------

The ``Parameter`` class inherits from
    :class:`~openstack.rds.v1.rdsresource.Resource`.

.. autoclass:: openstack.rds.v1.datastore.Parameter
   :members:

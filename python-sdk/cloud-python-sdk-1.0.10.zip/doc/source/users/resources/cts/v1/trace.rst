openstack.cts.v1.trace
======================

.. automodule:: openstack.cts.v1.trace

The Trace Class
---------------

The ``Trace`` class inherits from
    :class:`~openstack.cts.v1.ctsresource.Resource`.

.. autoclass:: openstack.cts.v1.trace.Trace
   :members:

The TraceV2 Class
-----------------

The ``TraceV2`` class inherits from
    :class:`~openstack.cts.v1.ctsresource.Resource`.

.. autoclass:: openstack.cts.v1.trace.TraceV2
   :members:

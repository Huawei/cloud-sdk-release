openstack.map_reduce.v1.job_execution
==========================

.. automodule:: openstack.map_reduce.v1.job_execution

The JobExecution Class
--------------

The ``JobExecution`` class inherits from :class:`~openstack.resource2.Resource`.

.. autoclass:: openstack.map_reduce.v1.job_execution.JobExecution
   :members:

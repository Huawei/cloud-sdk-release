openstack.rds_os.v1.datastore
=============================

.. automodule:: openstack.rds_os.v1.datastore

The Parameter Class
-------------------

The ``Parameter`` class inherits from
    :class:`~openstack.rds_os.v1.rds_osresource.Resource`.

.. autoclass:: openstack.rds_os.v1.datastore.Parameter
   :members:

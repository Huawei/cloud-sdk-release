openstack.object_store.v1.container
===================================

.. automodule:: openstack.object_store.v1.container

The Container Class
-------------------

The ``Container`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.object_store.v1.container.Container
   :members:

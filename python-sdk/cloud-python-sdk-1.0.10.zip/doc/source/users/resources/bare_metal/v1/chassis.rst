openstack.bare_metal.v1.chassis
===============================

.. automodule:: openstack.bare_metal.v1.chassis

The Chassis Class
-----------------

The ``Chassis`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.bare_metal.v1.chassis.Chassis
   :members:

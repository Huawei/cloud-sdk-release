openstack.smn.v2.topic
======================

.. automodule:: openstack.smn.v2.topic

The Topic Class
---------------

The ``Topic`` class inherits from
    :class:`~openstack.smn.v2.smnresource.Resource`.

.. autoclass:: openstack.smn.v2.topic.Topic
   :members:

The TopicAttr Class
-------------------

The ``TopicAttr`` class inherits from
    :class:`~openstack.smn.v2.smnresource.Resource`.

.. autoclass:: openstack.smn.v2.topic.TopicAttr
   :members:

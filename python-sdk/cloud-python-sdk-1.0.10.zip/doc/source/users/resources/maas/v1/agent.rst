openstack.maas.v1.agent
=======================

.. automodule:: openstack.maas.v1.agent

The Agent Class
-----------------

The ``Agent`` class inherits from :class:`~openstack.maas.v1.maasresource.Resource`.

.. autoclass:: openstack.maas.v1.agent.Agent
   :members:

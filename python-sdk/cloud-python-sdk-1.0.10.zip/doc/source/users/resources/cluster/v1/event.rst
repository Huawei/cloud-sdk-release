openstack.cluster.v1.event
==========================

.. automodule:: openstack.cluster.v1.event

The Event Class
---------------

The ``Event`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.cluster.v1.event.Event
   :members:

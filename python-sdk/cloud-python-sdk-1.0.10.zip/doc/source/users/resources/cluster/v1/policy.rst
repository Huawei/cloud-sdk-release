openstack.cluster.v1.policy
===========================

.. automodule:: openstack.cluster.v1.policy

The Policy Class
----------------

The ``Policy`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.cluster.v1.policy.Policy
   :members:

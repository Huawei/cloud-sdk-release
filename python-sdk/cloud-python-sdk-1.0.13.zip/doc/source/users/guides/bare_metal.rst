Using OpenStack Bare Metal
===========================

Before working with the Bare Metal service, you'll need to create a
connection to your OpenStack cloud by following the :doc:`connect` user
guide. This will provide you with the ``conn`` variable used in the examples
below.

.. TODO(Qiming): Implement this guide

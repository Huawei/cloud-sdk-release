openstack.network.v2.qos_dscp_marking_rule
==========================================

.. automodule:: openstack.network.v2.qos_dscp_marking_rule

The QoSDSCPMarkingRule Class
----------------------------

The ``QoSDSCPMarkingRule`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.qos_dscp_marking_rule.QoSDSCPMarkingRule
   :members:

openstack.network.v2.qos_bandwidth_limit_rule
=============================================

.. automodule:: openstack.network.v2.qos_bandwidth_limit_rule

The QoSBandwidthLimitRule Class
-------------------------------

The ``QoSBandwidthLimitRule`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.qos_bandwidth_limit_rule.QoSBandwidthLimitRule
   :members:

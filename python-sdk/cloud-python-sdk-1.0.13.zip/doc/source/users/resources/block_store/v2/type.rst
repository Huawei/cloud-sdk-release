openstack.block_store.v2.type
=============================

.. automodule:: openstack.block_store.v2.type

The Type Class
--------------

The ``Type`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.block_store.v2.type.Type
   :members:


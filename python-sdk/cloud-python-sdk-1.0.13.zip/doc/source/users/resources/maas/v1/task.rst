openstack.maas.v1.task
=======================

.. automodule:: openstack.maas.v1.task

The Task Class
-----------------

The ``Task`` class inherits from :class:`~openstack.maas.v1.maasresource.Resource`.

.. autoclass:: openstack.maas.v1.task.Task
   :members:

openstack.metric.v1.capabilities
================================

.. automodule:: openstack.metric.v1.capabilities

The Capabilities Class
----------------------

The ``Capabilities`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.metric.v1.capabilities.Capabilities
   :members:

openstack.compute.v2.server_interface
=====================================

.. automodule:: openstack.compute.v2.server_interface

The ServerInterface Class
-------------------------

The ``ServerInterface`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.compute.v2.server_interface.ServerInterface
   :members:

openstack.compute.v2.extension
==============================

.. automodule:: openstack.compute.v2.extension

The Extension Class
-------------------

The ``Extension`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.compute.v2.extension.Extension
   :members:
